
#!/bin/bash

# Install Chrome for Puppeteer
echo "Installing Chrome for Puppeteer..."
npx puppeteer browsers install chrome
echo "Chrome installed successfully!"
